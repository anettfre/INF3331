from .mandelbrot import *
import .mandelbrot_1 as mb1
import .mandelbrot_2 as mb2
import .mandelbrot_3 as mb3
