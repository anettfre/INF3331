from distutils.core import setup

setup(name="pakkemandelbrot",
      version="1.0",
      description="methods for computing mandelbrot set")
