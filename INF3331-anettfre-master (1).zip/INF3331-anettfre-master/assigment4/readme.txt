Readme
How to run my code:
4.1: python3 mandelbrot_1.py
4.2: python3 mandelbrot_2.py
4.3: python3 mandelbrot_3.py
4.5: python3 mandelbrot.py or python3 mandelbrot.py --help for help
4.6: python3 test_mandelbrot.py
     to install package use pip3 install pakkemandelbrot/
4.8: python3 replicator.py
