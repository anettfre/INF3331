import java.util.regex.Pattern;

class Integers {
  public static void main(String[] arguments) {
    int c; //declaring a variable
 
  /* Using a loop to repeat instruction execution */
 
    for (c = 1; c <= 10; c++) {
      System.out.println(c, true);
    }
    while (a != 0) {
      if (a < 0) {
        return false;
      }
    }
  }
}