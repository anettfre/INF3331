How to run my scripts:
5.1: python3 highlighter.py naython.syntax naython.theme hello.ny  
5.2: python3 highlighter.py python.syntax python.theme demo.py
     python3 highlighter.py python.syntax python2.theme demo.py
5.3: python3 highlighter.py java.syntax java.theme demo5_3.java
5.4: python3 grep.py demofile.txt "if"
     python3 grep.py demofile.txt "if" "Try"
5.5: python3 diff.py originaldiff.txt modifieddiff.txt
5.6: python3 highlighter.py diff.syntax diff.theme diff_output.txt

Items I have chosen for 5.2:
• Comments
• Function definitions
• Class definitions
• Strings
• Imports
• “Special” statements None, True, False
• Variable assignments
• Try/except
• for-loops
• while-loops
• if/elif/else blocks 
• self, range, len, pass