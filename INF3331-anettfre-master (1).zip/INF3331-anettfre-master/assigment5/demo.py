"""
sdfk
"""

from math import sqrt
import numpy as np

# this is a comment


class anette:
    def hei():
        print("Hallo", 123)
    hei()
    
    number = 5
    if number == 5:
        return None
            
    sqrt(14)
    while 20 > number:
        number += 1
    if number == 20:
        return True
        
    List = [2,4,6,78,8]
    a = len(List)
    for i in range(a):
        pass
    try:
        x = 5.0
    except ValueError:
        print("error")
