How to run my scripts:

6.1: 
python3 temperature_CO2_plotter.py

*Peer-review*
Det du har gjort ser greit ut, om enn kanskje litt enkelt. Skulle gjerne hatt en enklere måte å tilpasse input på, 
slik at man slipper å hardkode det inn. Men det er det eneste jeg har å si på det.
*Peer-review*

6.2: 
python3 web_visualization.py

*Peer-review*
Det viser frem bildene greit, men det viser ikke frem riktige bilder. 
*Peer-reveiw*

6.3-6.5: 
Have not done


