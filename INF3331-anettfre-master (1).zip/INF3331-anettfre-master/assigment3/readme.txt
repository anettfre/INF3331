Readme
3.1 Run my program with python3 wc.py * or  python3 wc.py *.py or python3 wc.py test1.txt
    test1.txt sould give 5 lines, 8 words and 35 character if atom is the editor, 4 lines for other
3.2-3.4 Run my program with python3 test_complex.py, this also runs my tests
